Conserved gene set considered for this study
